<?php
//database connection
($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost","root","","solanige_solanige_blog_admin_db"));  //host,user,password,database
?>
