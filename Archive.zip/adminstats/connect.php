<?php
$dsn='mysql:host=localhost;dbname=solanige_blog_admin_db';//dbname and host
$username='root';//username
$password='';//password
?>